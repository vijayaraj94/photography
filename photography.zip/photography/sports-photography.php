<?php include 'header.php';?>
<!-- 
<div class="page-title sixteen columns">
    <h1>Portfolio</h1>
</div>

<div class="clear"></div> -->

<div class="sixteen columns">
    <h6 class="section-header shadow" id="Sports_Photography">Sports Photography <span class="header-triangle-down"></span></h6>
    <p>During the course of his freelance photography work, Dinesh captured the dynamic moments of various sports events with great precision. He takes the snaps in the spirit of fun and liveliness.</p>
</div>
<div class="clear"></div>

<div class="sixteen columns clearfix margin40">
    <ul class="gallery_grid">   
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
                <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
            </a>
        </li>
    </ul>
</div>
<div class="clear"></div>

<?php include 'footer.php';?>