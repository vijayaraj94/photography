<?php include 'header.php';?>
<div class="page-title sixteen columns">
   <h1>Services</h1>
</div>
<div class="clear"></div>
<!-- BEGIN .content -->
<div class="content">
   <!-- BEGIN .row -->
   <div class="row">
      <div class="two-thirds column">
         <!-- BEGIN .hentry -->
         <div class="hentry shadow post-single">
            <div class="content-inner clearfix">
               <!-- BEGIN .post-top-wrap -->
               <div class="post-top-wrap">
                  <!-- BEGIN .post-image-wrapper -->
                  <!--<div class="post-image-wrap image-overlay">
                     <a href="photos/8.jpg" data-rel="prettyPhoto">
                     
                     	<img src="photos/920x360/8.jpg" alt="photo" />
                     
                     </a>
                     
                     </div>-->
                  <!-- END .post-image-wrapper -->
               </div>
               <!-- END .post-top-wrap -->
               <p>
                  I provide a range of photography services such as Event photography: conferences, launching, concerts, shows, exhibitions, festivals, weddings, anniversaries, competitions, demonstrations, sports events and household functions. Please contact me at 9884052286 
               </p>
               <div class="clear"></div>
            </div>
         </div>
         <!-- END .hentry -->
      </div>
      <!-- BEGIN .sidebar -->
      <div class="one-third column shadow sidebar">
         <div class="content-inner clearfix">
            <!-- BEGIN .widget -->
            <div class="widget clearfix">
               <h6 class="dotted-header"><span>Portfolio</span></h6>
               <ul class="lp-sidebar">
                  <li>
                     <div class="lp-image">
                        <a title="Wildlife Photography" href="portfolio.php#Wildlife_Photography">
                        <img src="admin/gallery/Portfolio1486618358.jpg" width="50" height="50" alt="Wildlife Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Wildlife Photography" href="portfolio.php#Wildlife_Photography">Wildlife Photography</a></h5>
                        <p>Dinesh has a special craving for capturing wildlif...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Sports Photography" href="portfolio.php#Sports_Photography">
                        <img src="admin/gallery/Portfolio1486618358.jpg" width="50" height="50" alt="Sports Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Sports Photography" href="portfolio.php#Sports_Photography">Sports Photography</a></h5>
                        <p>During the course of his freelance photography wor...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Portraits and Candid photography" href="portfolio.php#Portraits_and_Candid_photography">
                        <img src="admin/gallery/Portfolio1486618358.jpg" width="50" height="50" alt="Portraits and Candid photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Portraits and Candid photography" href="portfolio.php#Portraits_and_Candid_photography">Portraits and Candid photography</a></h5>
                        <p>He is skilled at taking timeless shots of all beau...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Travel Photography" href="portfolio.php#Travel_Photography">
                        <img src="admin/gallery/Portfolio1486618358.jpg" width="50" height="50" alt="Travel Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Travel Photography" href="portfolio.php#Travel_Photography">Travel Photography</a></h5>
                        <p>Dinesh has a zest for traveling new places and gat...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Street Photography" href="http://www.dineshphotography.com/portfolio.php#Street_Photography">
                        <img src="admin/gallery/Portfolio1486618358.jpg" width="50" height="50" alt="Street Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Street Photography" href="http://www.dineshphotography.com/portfolio.php#Street_Photography">Street Photography</a></h5>
                        <p>As a freelancer photographer in Chennai, Dinesh ha...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
               </ul>
            </div>
            <!-- END .widget -->
         </div>
      </div>
      <!-- END .sidebar -->
   </div>
   <!-- END .row -->
   <div class="clear"></div>
</div>
<!-- END .content -->

<?php include 'footer.php';?>