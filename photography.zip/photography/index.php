<?php include 'header.php';?>
<div class="sixteen columns">
	<!-- BEGIN .flexslider -->
	<div class="flexslider">
		<ul class="slides shadow">
	       	<li>
	          	<img src="admin/homeslider/Banner1486619553.jpg" alt="" />
	       	</li>
	       	<li>
	          	<img src="admin/homeslider/Banner1486619569.jpg" alt="" />
	       	</li>
	       	<li>
	          	<img src="admin/homeslider/Banner1486619588.jpg" alt="" />
	       	</li>
	    </ul>
	</div>
	<!-- END .flexslider -->
</div>
<div class="clear"></div>
<div class="sixteen columns slogan shadow">
	<div class="content-inner clearfix home_block">
	<div class="two_fifth_fluid">
   		&nbsp;
	</div>
	<div class="three_fifth_fluid last">
   		<h4 class="title">Welcome to my website</h4>
   		<p style="line-height:150%;">Hello! Welcome to Dineshphotography where I share my passion. I will be posting my recent works, events photos, and my random clicks! Please visit my portfolio page and click on any specific category you would like to take a look at. Wildlife Photography is my passion. If you wish to use my services kindly contact me.<br>Thank you!</p>
   		<a href="contact.php" class="button large">Contact me</a>
	</div>
	</div>
</div>
<div class="clear"></div>
<div class="clear"></div>
<!-- BEGIN Carousel -->
<div class="sixteen columns">
<h6 class="section-header shadow">Portfolio<span class="header-triangle-down"></span></h6>
</div>
<div class="clear"></div>
<div class="sixteen columns clearfix margin40">
	<div class="jcarousel-wrapper">
		<div class="jcarousel" data-jcarousel="true">
	       	<ul style="left: 0px; top: 0px;">
	          	<li>
	             	<a href="admin/gallery/Portfolio1486618328.jpg" data-lightbox="prettyPhoto" data-title="Portfolio">
	             		<img src="admin/gallery/Portfolio1486618328.jpg" alt="" />
	             	</a>
	          	</li>
	          	<li>
	             	<a href="admin/gallery/Portfolio1486618371.jpg" data-lightbox="prettyPhoto" data-title="Portfolio">
	             		<img src="admin/gallery/Portfolio1486618371.jpg" alt="" />
	             	</a>
	          	</li>
	          	<li>
	            	<a href="admin/gallery/Portfolio1486618384.jpg" data-lightbox="prettyPhoto" data-title="Portfolio">
	             		<img src="admin/gallery/Portfolio1486618384.jpg" alt="" />
	             	</a>
	          	</li>
	          	<li>
	             	<a href="admin/gallery/Portfolio1486618341.jpg" data-lightbox="prettyPhoto" data-title="Portfolio">
	             		<img src="admin/gallery/Portfolio1486618341.jpg" alt="" />
	             	</a>
	          	</li>
	          	<li>
	             	<a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="prettyPhoto" data-title="Portfolio">
	             		<img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
	             	</a>
	          	</li>
	          	<li>
	             	<a href="admin/gallery/Portfolio1486618397.jpg" data-lightbox="prettyPhoto" data-title="Portfolio">
	             		<img src="admin/gallery/Portfolio1486618397.jpg" alt="" />
	             	</a>
	          	</li>
	          	<li>
	            	<a href="admin/gallery/Portfolio1486618410.jpg" data-lightbox="prettyPhoto" data-title="Portfolio">
	             		<img src="admin/gallery/Portfolio1486618410.jpg" alt="" />
	             	</a>
	          	</li>
	       	</ul>
	    </div>
	    <a href="#" class="jcarousel-control-prev" data-jcarouselcontrol="true">‹</a>
	    <a href="#" class="jcarousel-control-next" data-jcarouselcontrol="true">›</a>
	</div>
</div>
<div class="clear"></div>
<?php include 'footer.php';?>