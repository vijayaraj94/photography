<?php include 'header.php';?>
<div class="page-title sixteen columns">
  <h1>About Manikandan</h1>
</div>
<div class="clear"></div>
<!-- BEGIN .content -->
<div class="content">
   <!-- BEGIN .row -->
   <div class="row">
      <div class="two-thirds column">
         <!-- BEGIN .hentry -->
         <div class="hentry shadow post-single">
            <div class="content-inner clearfix">
               <!-- BEGIN .post-top-wrap -->
               <div class="post-top-wrap">
                  <!-- BEGIN .post-image-wrapper -->
                  <div class="post-image-wrap image-overlay">
                     <a href="images/about.jpg" data-lightbox="about" data-title="Dinesh Kumar Ravi">
                     <img src="images/about.jpg" alt="photo" />
                     </a>
                  </div>
                  <!-- END .post-image-wrapper -->
               </div>
               <!-- END .post-top-wrap -->
               <p>
                  Dinesh Kumar Ravi is an IT professional working as a freelancer photographer in Chennai. He enjoys exploring new places and garnering memorable life experiences. His love for wildlife photography is apparent in much of his work. His images boast of a celebration of life and natural beauty. He takes pride in his ability to capture aesthetically pleasing moments with great precision.
                  <br><br>
                  Dinesh has an extensive experience of covering various sports events. These images are full of dynamism and energy. The work areas of his freelance photography also include street photography, wedding photography and travel photography. His snapshots portray an admiration for culture, emotions, and simplicity rather than just recording an artistic sight.
                  <br><br>
                  His wedding shots capture the magical moments of bride and groom. From the serene depictions of Lakes to the captivating aura of tea plantation, each of his travel pictures has a unique story to tell.
                  <br><br>
                  His street photography work represents art and culture in its raw form. There is a vibrant blend of light and colors to represent everyday life of people. The strength of his photography lies in the articulate depiction of moments that arise feelings of reverence and awe in the beholder. 
               </p>
               <div class="clear"></div>
            </div>
         </div>
         <!-- END .hentry -->
      </div>
      <!-- BEGIN .sidebar -->
      <div class="one-third column shadow sidebar">
         <div class="content-inner clearfix">
            <!-- BEGIN .widget -->
            <div class="widget clearfix">
               <h6 class="dotted-header"><span>Portfolio</span></h6>
               <ul class="lp-sidebar">
                  <li>
                     <div class="lp-image">
                        <a title="Wildlife Photography" href="portfolio.php#Wildlife_Photography">
                        <img src="admin/gallery/Portfolio1486618328.jpg" width="50" height="50" alt="Wildlife Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Wildlife Photography" href="portfolio.php#Wildlife_Photography">Wildlife Photography</a></h5>
                        <p>Dinesh has a special craving for capturing wildlif...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Sports Photography" href="portfolio.php#Sports_Photography">
                        <img src="admin/gallery/Portfolio1486618371.jpg" width="50" height="50" alt="Sports Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Sports Photography" href="portfolio.php#Sports_Photography">Sports Photography</a></h5>
                        <p>During the course of his freelance photography wor...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Portraits and Candid photography" href="portfolio.php#Portraits_and_Candid_photography">
                        <img src="admin/gallery/Portfolio1486618384.jpg" width="50" height="50" alt="Portraits and Candid photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Portraits and Candid photography" href="portfolio.php#Portraits_and_Candid_photography">Portraits and Candid photography</a></h5>
                        <p>He is skilled at taking timeless shots of all beau...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Travel Photography" href="portfolio.php#Travel_Photography">
                        <img src="admin/gallery/Portfolio1486618341.jpg" width="50" height="50" alt="Travel Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Travel Photography" href="portfolio.php#Travel_Photography">Travel Photography</a></h5>
                        <p>Dinesh has a zest for traveling new places and gat...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
                  <li>
                     <div class="lp-image">
                        <a title="Street Photography" href="portfolio.php#Street_Photography">
                        <img src="admin/gallery/Portfolio1486618358.jpg" width="50" height="50" alt="Street Photography"/>
                        </a>
                     </div>
                     <div class="lp-description clearfix">
                        <h5><a title="Street Photography" href="portfolio.php#Street_Photography">Street Photography</a></h5>
                        <p>As a freelancer photographer in Chennai, Dinesh ha...</p>
                     </div>
                     <div class="clear"></div>
                  </li>
               </ul>
            </div>
            <!-- END .widget -->
         </div>
      </div>
      <!-- END .sidebar -->
   </div>
   <!-- END .row -->
   <div class="clear"></div>
</div>
<!-- END .content -

<?php include 'footer.php';?>