<?php include 'header.php';?>

<div class="page-title sixteen columns">
    <h1>Events & Workshops</h1>
</div>

<div class="clear"></div>

<div class="sixteen columns">
    <h6 class="section-header shadow" id="Photography_Basics_workshop_at_Isha_Vidhya,_Villupuram">Photography Basics workshop at Isha Vidhya, Villupuram <span class="header-triangle-down"></span></h6>
    <p><p>Conducting the photography basics workshop was one of most rewarding experience for me in my lifetime. This workshop which was held at Isha Vidya School, Villupuram on 19th November 2016 was aimed 9th and 11th grade rural students. Around 40 children aged about 12-15 years attended the workshop which basically had 2 modules. The first module was on &ldquo;The story of my journey in photography&rdquo; followed by an interactive workshop on &ldquo;Photography Basics&rdquo;.</p>

	<p>The session had Photography Basics followed by an activity to shoot certain objects in the school premises using point and shoot camera. It was first of its kind experience for the kids; they were eager to shoot and thoroughly enjoyed learning some of practical aspects of photography. Photos captured by the students were reviewed and suggestions were given for taking better photos.</p>

	<p>The workshop gave me an opportunity to expose the rural children to nature, wildlife, street photography, thereby kindle their creativity. The activity was initiated by Ms Peggy Wolff from Isha Vidya to make education more interesting for rural kids; I humbly thank her for this opportunity.&nbsp;</p>
	</p>
</div>

<div class="clear"></div>


<div class="sixteen columns clearfix margin40">
	<ul class="gallery_grid event_gal">
		<li>
            <a href="admin/gallery/Portfolio1486618397.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618397.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
		<li>
            <a href="admin/gallery/Portfolio1486618410.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618410.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
		<li>
            <a href="admin/gallery/Portfolio1486618397.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618397.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618410.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618410.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618397.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618397.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618410.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618410.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618397.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618397.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618410.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618410.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618397.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618397.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618410.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618410.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618397.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618397.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
        <li>
            <a href="admin/gallery/Portfolio1486618410.jpg" data-lightbox="Photography Basics workshop at Isha Vidhya, Villupuram" data-title="Photography Basics workshop at Isha Vidhya, Villupuram">
                <img src="admin/gallery/Portfolio1486618410.jpg" alt="Photography Basics workshop at Isha Vidhya, Villupuram" />
            </a>
        </li>
    </ul>
</div>

<div class="clear"></div>
<div class="page_no_holder"></div>

<?php include 'footer.php';?>