					
		</div>
   		<!-- END .container -->
   		<!-- BEGIN #footer-bottom-wrapper -->
   		<div id="footer-bottom-wrapper" class="container">
      	<!-- BEGIN #footer-bottom -->
      	<div id="footer-bottom">
         	<div class="six columns">
            	<div class="copyright">
               		<p>Copyright &copy; 2018 maniphotography.com</p>
            	</div>
         	</div>
         	<div class="ten columns">
            	<div class="footer-nav">
	               	<ul>
	                  	<li><a href="index.php">Homepage</a></li>
	                  	<li><a href="about.php">About</a></li>
	                  	<li><a href="portfolio.php">Portfolio</a></li>
	                  	<li><a href="services.php">Services</a></li>
	                  	<li><a href="contact.php">Contact</a></li>
               	</ul>
            	</div>
         	</div>
        	<div class="clear"></div>
      	</div>
      	<!-- END #footer-bottom -->
   	</div>
   	<!-- END #footer-bottom-wrapper -->
   	<!-- JS -->
	<script src="js/jquery.ui-custom.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.preloader.js"></script>
	<script src="js/jquery.tipTip.js"></script>
	<script src="js/jquery.uitotop.js"></script>
	<script src="js/jquery.prettyPhoto.js"></script>
	<script src="js/jquery.flexslider.js"></script>
	<script src="js/jquery.tweetable.js"></script>
	<script src="js/jquery.jflickrfeed.js"></script>
	<script src="js/jquery.fitvids.js"></script>
	<script src="js/jquery.elastislide.js"></script>
	<script src="js/scripts.js"></script>
	<script src="js/lightbox.js"></script>
</body>
</html>