<!DOCTYPE html>
	<!--[if lt IE 7 ]><html class="ie ie6" lang="en"><![endif]-->
   	<!--[if IE 7 ]><html class="ie ie7" lang="en"><![endif]-->
    <!--[if IE 8 ]><html class="ie ie8" lang="en"><![endif]-->
    <!--[if (gte IE 9)|!(IE)]><!--><html lang="en"><!--<![endif]-->
   	<head>
		<meta charset="utf-8">
		<title>Mani Photography</title>
		<meta name="description" content="Mani Photography enjoys exploring wildlife photography, sports photography, street Photography, candid and travels photography High Definition Photos taken service every aspect of the photograph." />
		<meta name="keywords" content="wildlife photography, sports photography, street photography, travel photography, portraits &amp; candid photography" />
		<meta name="robots" content="index,follow" />
		<meta name="revisit-after" content="5 days" />
		<meta property="og:locale" content="en_US" />
		<meta property="og:title" content="Mani Photography – Wildlife, Sports, Street, Travel, Portraits &amp; Candid Photography" />
		<meta property="og:description" content="Mani Photography enjoys exploring wildlife photography, sports photography, street Photography, candid and travels photography High Definition Photos taken service every aspect of the photograph."/>
		<meta property="og:url" content="index.php"/>
		<meta property="og:site_name" content="Mani Photography"/>
		<meta property="og:type" content="article"/>
		<link rel="author" href="https://www.facebook.com/Maniphotographi" />
		<meta property="og:image" content="admin/gallery/Banner1486619553.jpg"/>
		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<!-- Mobile Specific Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<!-- Stylesheets -->
		<link rel="stylesheet" href="css/base.css">
		<link rel="stylesheet" href="css/layout.css">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/skeleton.css">
		<link rel="stylesheet" href="css/flexslider.css">
		<link rel="stylesheet" href="css/prettyPhoto.css">
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,600,400italic" type="text/css">
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Serif" type="text/css">
		<link rel="stylesheet" href="css/dark.css">
		<link rel="stylesheet" href="css/lightbox.css">
		<link rel="stylesheet" type="text/css" href="src/jcarousel.css">
		<!-- JS -->
		<script src="js/jquery-1.7.1.min.js"></script>
		<!-- Favicons -->
		<link rel="shortcut icon" href="images/icons/favicon.ico">
		<link rel="apple-touch-icon" href="images/icons/apple-touch-icon.png">
		<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
		<!-- Hook up the FlexSlider -->
		<script type="text/javascript">
			$(window).load(function() {
				$('.flexslider').flexslider();
			});

			$(document).ready(function(){
				$('#elastic-carousel').elastislide({
					imageW 		: 180,
					minItems	: 3,
					margin		: 2,
					border		: 0,
					current		: 12
				});
			});

			$(document).ready(function(){
				$('#elastic-carousela').elastislide({
					imageW 		: 180,
					minItems	: 3,
					margin		: 2,
					border		: 0,
					current		: 12
				});
			});

			$(document).ready(function(){
				$('#elastic-carouselb').elastislide({
					imageW 		: 180,
					minItems	: 3,
					margin		: 2,
					border		: 0,
					current		: 12
				});
			});

			$(document).ready(function(){
				$('#elastic-carouselc').elastislide({
					imageW 		: 180,
					minItems	: 3,
					margin		: 2,
					border		: 0,
					current		: 12
				});
			});

			$(document).ready(function(){
				$('#elastic-carouseld').elastislide({
					imageW 		: 180,
					minItems	: 3,
					margin		: 2,
					border		: 0,
					current		: 12
				});
			});
		</script>
		<script type="text/javascript" src="src/jquery_002.js"></script>
		<script type="text/javascript" src="src/jcarousel.js"></script>
		<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)	  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');	  ga('create', 'UA-96661032-1', 'auto');	  ga('send', 'pageview');	
		</script>
    </head>
    <body>
       <!-- BEGIN .info-top -->
       <div class="info-top shadow">
          	<div class="container">
             	<div class="info-text eight columns">
                	<p>E-mail: info@maniphotography.com | Mobile: +91 9884052286</p>
             	</div>
             	<div class="info-social eight columns">
                	<ul>
                   		<li><a href="#" class="social-fb">Facebook</a></li>
                   		<li><a href="#" target="_blank" class="social-fl">Flickr</a></li>
                   		<li><a href="#" target="_blank" class="social-tw">Twitter</a></li>
                	</ul>
             	</div>
          	</div>
       </div>
       <!-- END .info-top -->

       <!-- BEGIN .container -->
       <div class="container">
          	<!-- BEGIN .header -->
          	<div class="header sixteen columns">
             	<div class="logo"><a href="index.php"><img src="images/logo5.png" alt="logo"  style="max-width:285px;"/></a></div>
             	<!-- BEGIN #nav-wrapper -->
             	<div id="nav-wrapper">
                	<!-- BEGIN #nav -->
                	<ul id="nav" class="radius">
	                   	<li><a href="index.php">Homepage</a></li>
	                   	<li><a href="about.php">About</a></li>
                   		<li><a href="portfolio.php">Portfolio</a></li>
                   		<li>
                      		<a href="services.php">Services</a>
                      		<ul>
	                         	<li><a href="wildlife-photography.php">Wildlife Photography</a></li>
	                         	<li><a href="sports-photography.php">Sports Photography</a></li>
                      		</ul>
                   		</li>
                   		<li><a href="eventandworkshop.php">Events & Workshops</a></li>
                   		<li><a href="contact.php">Contact</a></li>
                	</ul>
                	<!-- END #nav -->
                	<!-- BEGIN #responsive-nav -->
                	<div id="responsive-nav">
                   		<select onchange="location.href = document.getElementById('page-selector').value;" name="page-selector" id="page-selector">
	                      	<option value="">Select a Page</option>
	                      	<option value="index.php">Homepage</option>
	                      	<option value="about.php">About</option>
	                      	<option value="portfolio.php">Portfolio</option>
	                      	<option value="services.php">Services</option>
	                      	<ul>
	                         	<li><a href="wildlife-photography.php">Wildlife Photography</a></li>
	                         	<li><a href="sports-photography.php">Sports Photography</a></li>
	                      	</ul>
	                      	</li>
	                      	<option value="contact.php">Contact</option>
                   		</select>
                	</div>
                	<!-- END #responsive-nav -->
             	</div>
             	<!-- END #nav-wrapper -->
          	</div>
          	<!-- END .header -->
          	<div class="clear"></div>