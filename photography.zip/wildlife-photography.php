<?php include 'header.php';?>

<div class="page-title sixteen columns">
    <h1>Portfolio</h1>
</div>

<div class="clear"></div>

<div class="sixteen columns">
    <h6 class="section-header shadow" id="Wildlife_Photography">Wildlife Photography <span class="header-triangle-down"></span></h6>
    <p>Dinesh has a special craving for capturing wildlife in all its natural glory. The natural wonderment of animals, trees, plant and birds all gets skillfully caught in his wildlife shots.</p>
</div>

<div class="clear"></div>

<div class="sixteen columns clearfix margin40">
	<ul class="gallery_grid">	
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
				
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
		<li>
		    <a href="admin/gallery/Portfolio1486618358.jpg" data-lightbox="" data-title="">
		        <img src="admin/gallery/Portfolio1486618358.jpg" alt="" />
		    </a>
		</li>
   	</ul>
</div>
<div class="clear"></div>

<?php include 'footer.php';?>