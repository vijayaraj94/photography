<?php include 'header.php';?>

	<div class="page-title sixteen columns">
		<h1>Contact Me</h1>
	</div>
	<div class="clear"></div>
    
    <!-- BEGIN .content -->
	<div class="content">
		<!-- BEGIN .row -->
		<div class="row">
			<!-- <div class="sixteen columns shadow margin20">
				<div class="content-inner clearfix">

					<div class="google-map">
						<iframe src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=pl&amp;geocode=&amp;q=new+york&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=50.291089,114.169922&amp;ie=UTF8&amp;hq=&amp;hnear=Nowy+Jork,+New+York,+Nowy+Jork&amp;t=m&amp;z=11&amp;ll=40.714353,-74.005973&amp;output=embed"></iframe>
					</div>

				</div>
			</div> -->
			<div class="clear"></div>				
			<!-- BEGIN .eight columns -->
			<div class="eight columns shadow sidebar">
				<div class="content-inner clearfix">
					<!-- BEGIN #contact -->
					<div id="contact">
						<div id="message"></div>
                        <img src="images/contact.jpg">
					</div>
					<!-- END #contact -->
					<div class="clear"></div>
				</div>
			</div>
			<!-- END .eight columns -->

			<!-- BEGIN .eight columns -->
			<div class="eight columns shadow">
				<div class="content-inner clearfix">
					<h6 class="dotted-header"><span>My address</span></h6>
					<div class="contact-details">
						<h6>Dinesh</h6>
						<span class="contact-address">2 Elizabeth St, Melbourne, Victoria 3000 Australia</span>
						<span class="contact-phone">+91 9884052286</span>
						<span class="contact-mail"><a href="mailto:info@dineshphotography.com">info@dineshphotography.com</a></span>
					</div>
					<div class="clear"></div>
				</div>
			</div>
			<!-- END .eight columns -->
		</div>
		<!-- END .row -->
		<div class="clear"></div>
	</div>
	<!-- END .content -->

<?php include 'footer.php';?>